/**
 * Input validation utilities for WASM data and user input
 * Centralizes all validation logic for better security and maintainability
 */

// Message validation
export function validateMessages(messages) {
  if (!Array.isArray(messages)) {
    throw new Error('Messages must be an array');
  }
  
  messages.forEach((msg, index) => {
    if (!msg || typeof msg !== 'object') {
      throw new Error(`Message at index ${index} must be an object`);
    }
    if (typeof msg.text !== 'string' || msg.text.length > 1000) {
      throw new Error(`Message at index ${index}: text must be string <= 1000 chars`);
    }
    if (!Number.isFinite(msg.timestamp) || msg.timestamp <= 0) {
      throw new Error(`Message at index ${index}: timestamp must be positive number`);
    }
    if (msg.author && (typeof msg.author !== 'string' || msg.author.length > 50)) {
      throw new Error(`Message at index ${index}: author must be string <= 50 chars`);
    }
  });
  
  return true;
}

// WASM AnalysisResult validation
export function validateAnalysisResult(result) {
  if (!result || typeof result !== 'object') {
    throw new Error('Invalid result: must be an object');
  }
  
  // Validate buckets
  if (!Array.isArray(result.buckets)) {
    throw new Error('Invalid result: buckets must be an array');
  }
  result.buckets.forEach((bucket, index) => {
    if (!bucket || typeof bucket !== 'object') {
      throw new Error(`Invalid bucket at index ${index}: must be an object`);
    }
    if (typeof bucket.label !== 'string' || bucket.label.length > 100) {
      throw new Error(`Invalid bucket at index ${index}: label must be a string <= 100 chars`);
    }
    if (!Number.isFinite(bucket.count) || bucket.count < 0) {
      throw new Error(`Invalid bucket at index ${index}: count must be a non-negative number`);
    }
    if (!Array.isArray(bucket.sample_messages)) {
      throw new Error(`Invalid bucket at index ${index}: sample_messages must be an array`);
    }
    bucket.sample_messages.forEach((msg, msgIndex) => {
      if (typeof msg !== 'string' || msg.length > 500) {
        throw new Error(`Invalid message at bucket ${index}, message ${msgIndex}: must be string <= 500 chars`);
      }
    });
  });
  
  // Validate topics
  if (result.topics && !Array.isArray(result.topics)) {
    throw new Error('Invalid result: topics must be an array if present');
  }
  if (result.topics) {
    result.topics.forEach((topic, index) => {
      if (!topic || typeof topic !== 'object') {
        throw new Error(`Invalid topic at index ${index}: must be an object`);
      }
      if (typeof topic.term !== 'string' || topic.term.length > 50) {
        throw new Error(`Invalid topic at index ${index}: term must be string <= 50 chars`);
      }
      if (!Number.isFinite(topic.count) || topic.count <= 0) {
        throw new Error(`Invalid topic at index ${index}: count must be positive number`);
      }
      if (typeof topic.is_emote !== 'boolean') {
        throw new Error(`Invalid topic at index ${index}: is_emote must be boolean`);
      }
    });
  }
  
  // Validate sentiment signals
  if (result.sentiment_signals && typeof result.sentiment_signals !== 'object') {
    throw new Error('Invalid result: sentiment_signals must be an object if present');
  }
  
  if (result.sentiment_signals) {
    const sentimentFields = ['positive_count', 'negative_count', 'confused_count', 'neutral_count'];
    sentimentFields.forEach(field => {
      if (!Number.isFinite(result.sentiment_signals[field]) || result.sentiment_signals[field] < 0) {
        throw new Error(`Invalid sentiment_signals.${field}: must be non-negative number`);
      }
    });
  }
  
  // Validate processed_count
  if (!Number.isFinite(result.processed_count) || result.processed_count < 0) {
    throw new Error('Invalid result: processed_count must be a non-negative number');
  }
  
  return true;
}

// Settings validation
export function validateSettings(settings) {
  if (!settings || typeof settings !== 'object') {
    throw new Error('Settings must be an object');
  }
  
  // Validate topicMinCount
  if (!Number.isFinite(settings.topicMinCount) || settings.topicMinCount < 1 || settings.topicMinCount > 100) {
    throw new Error('topicMinCount must be a number between 1 and 100');
  }

  // Validate spamThreshold
  if (!Number.isFinite(settings.spamThreshold) || settings.spamThreshold < 1 || settings.spamThreshold > 10) {
    throw new Error('spamThreshold must be a number between 1 and 10');
  }

  // Validate duplicateWindow
  if (!Number.isFinite(settings.duplicateWindow) || settings.duplicateWindow < 5 || settings.duplicateWindow > 300) {
    throw new Error('duplicateWindow must be a number between 5 and 300 seconds');
  }

  // Validate analysisWindowSize
  if (settings.analysisWindowSize !== undefined) {
    if (!Number.isFinite(settings.analysisWindowSize) ||
        !Number.isInteger(settings.analysisWindowSize) ||
        settings.analysisWindowSize < 50 ||
        settings.analysisWindowSize > 1000) {
      throw new Error('analysisWindowSize must be an integer between 50 and 1000');
    }
  }

  // Validate inactivityTimeout
  if (settings.inactivityTimeout !== undefined) {
    if (!Number.isFinite(settings.inactivityTimeout) || settings.inactivityTimeout < 30 || settings.inactivityTimeout > 600) {
      throw new Error('inactivityTimeout must be a number between 30 and 600 seconds');
    }
  }

  // Validate sentimentSensitivity
  if (settings.sentimentSensitivity !== undefined) {
    if (!Number.isFinite(settings.sentimentSensitivity) || settings.sentimentSensitivity < 1 || settings.sentimentSensitivity > 10) {
      throw new Error('sentimentSensitivity must be a number between 1 and 10');
    }
  }

  // Validate moodUpgradeThreshold
  if (settings.moodUpgradeThreshold !== undefined) {
    if (!Number.isFinite(settings.moodUpgradeThreshold) || settings.moodUpgradeThreshold < 10 || settings.moodUpgradeThreshold > 50) {
      throw new Error('moodUpgradeThreshold must be a number between 10 and 50');
    }
  }

  // Validate boolean settings
  if (typeof settings.aiSummariesEnabled !== 'boolean') {
    throw new Error('aiSummariesEnabled must be a boolean');
  }
  
  return true;
}
