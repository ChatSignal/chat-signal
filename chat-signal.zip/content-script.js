// Content script for YouTube/Twitch live chat monitoring

const DEBUG = false;
const BATCH_INTERVAL = 5000; // 5 seconds
let messageBatch = [];

const isTestEnv = typeof globalThis !== 'undefined' && globalThis.__CHAT_SIGNAL_RADAR_TEST__ === true;

// Detect platform
const isYouTube = window.location.hostname.includes('youtube.com');
const isTwitch = window.location.hostname.includes('twitch.tv');

// YouTube chat selector
const YOUTUBE_CHAT_SELECTOR = 'yt-live-chat-text-message-renderer';
// Twitch chat selector
const TWITCH_CHAT_SELECTOR = '.chat-line__message';

function extractYouTubeMessage(element) {
  const authorElement = element.querySelector('#author-name');
  const messageElement = element.querySelector('#message');

  if (!authorElement || !messageElement) return null;

  return {
    text: messageElement.textContent.trim(),
    author: authorElement.textContent.trim(),
    timestamp: Date.now()
  };
}

function extractTwitchMessage(element) {
  const authorElement = element.querySelector('.chat-author__display-name');
  const messageElement = element.querySelector('.text-fragment');

  if (!authorElement || !messageElement) return null;

  return {
    text: messageElement.textContent.trim(),
    author: authorElement.textContent.trim(),
    timestamp: Date.now()
  };
}

let currentObserver = null;
let currentContainer = null;
let batchTimer = null;
let containerMonitor = null;
let lastUrl = window.location.href;
let navObserver = null;

function observeChat() {
  startBatchTimer();
  startContainerWatcher();
  startNavigationWatcher();
  startContainerMonitor();
}

function startBatchTimer() {
  if (batchTimer) {
    return;
  }

  batchTimer = setInterval(() => {
    if (messageBatch.length > 0) {
      chrome.runtime.sendMessage({
        type: 'CHAT_MESSAGES',
        messages: messageBatch,
        platform: isYouTube ? 'youtube' : 'twitch',
        streamUrl: window.location.href,
        streamTitle: document.title
      }).catch(() => {}); // Side panel may be closed
      messageBatch = [];
    }
  }, BATCH_INTERVAL);
}

function startContainerWatcher() {
  const MAX_RETRIES = 30; // 30 seconds
  let retryCount = 0;

  const checkForChat = setInterval(() => {
    retryCount++;
    const nextContainer = findChatContainer();

    if (nextContainer && nextContainer !== currentContainer) {
      clearInterval(checkForChat);
      attachObserver(nextContainer);
    } else if (retryCount >= MAX_RETRIES) {
      clearInterval(checkForChat);
      console.warn('[Chat Signal] Chat container not found after 30 seconds. Chat may not be available on this page.');
    }
  }, 1000);
}

function startContainerMonitor() {
  if (containerMonitor) {
    return;
  }

  containerMonitor = setInterval(() => {
    if (!currentContainer) {
      return;
    }
    const ownerDoc = currentContainer.ownerDocument || document;
    const stillPresent = ownerDoc.contains(currentContainer);
    if (!stillPresent) {
      resetObserver();
      startContainerWatcher();
    }
  }, 5000);
}

function startNavigationWatcher() {
  if (navObserver) return;
  navObserver = true; // guard against double-init

  function onNavigate() {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      resetObserver();
      startContainerWatcher();
    }
  }

  // Intercept SPA navigations (YouTube uses pushState/replaceState)
  const origPushState = history.pushState;
  const origReplaceState = history.replaceState;
  history.pushState = function () {
    origPushState.apply(this, arguments);
    onNavigate();
  };
  history.replaceState = function () {
    origReplaceState.apply(this, arguments);
    onNavigate();
  };
  window.addEventListener('popstate', onNavigate);
}

function findChatContainer() {
  if (isYouTube) {
    const iframe = document.querySelector('iframe#chatframe');
    if (iframe) {
      try {
        const iframeDoc = iframe.contentDocument;
        if (iframeDoc) {
          return iframeDoc.querySelector('#items');
        }
      } catch (error) {
        if (DEBUG) console.warn('[Chat Signal] Unable to access YouTube chat iframe:', error);
      }
    }
    return document.querySelector('yt-live-chat-item-list-renderer #items');
  }

  if (isTwitch) {
    return document.querySelector('.chat-scrollable-area__message-container');
  }

  return null;
}

function attachObserver(container) {
  resetObserver();
  currentContainer = container;
  const platform = isYouTube ? 'YouTube' : 'Twitch';
  if (DEBUG) console.log(`[Chat Signal] Started observing ${platform} chat`);

  currentObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const messageElement = node.matches(getSelector()) ? node : node.querySelector(getSelector());
          if (messageElement) {
            const extractor = isYouTube ? extractYouTubeMessage : extractTwitchMessage;
            const message = extractor(messageElement);
            if (message) {
              messageBatch.push(message);
            }
          }
        }
      });
    });
  });

  currentObserver.observe(container, {
    childList: true,
    subtree: true
  });
}

function resetObserver() {
  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }
  currentContainer = null;
}

function getSelector() {
  return isYouTube ? YOUTUBE_CHAT_SELECTOR : TWITCH_CHAT_SELECTOR;
}

// Start observing when DOM is ready
if (!isTestEnv) {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observeChat);
  } else {
    observeChat();
  }
}

const ChatSignalRadarContent = {
  extractYouTubeMessage,
  extractTwitchMessage,
  getSelector,
  findChatContainer
};

if (typeof globalThis !== 'undefined') {
  globalThis.ChatSignalRadarContent = ChatSignalRadarContent;
}
